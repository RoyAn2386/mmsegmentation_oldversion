_base_ = [
    '../_base_/models/danet_r50-d8.py',# ok, giữ nguyên
    '../_base_/datasets/CustomDataset.py', '../_base_/default_runtime.py',
    '../_base_/schedules/schedule_40k.py'
]
model = dict(
    decode_head=dict(num_classes=5), auxiliary_head=dict(num_classes=5))
# sửa tất cả đường dẫn và tên file mình đã cài đặt từ trước trong mục _base_ của file này